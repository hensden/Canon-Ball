Controls: 
KEYBOARD
A/B to oscillate cannonhead
Space to launch
F/S to increase/decease the launch speed
R to reset ball
Zoom in/Zoom out: Up arrow/ down arrow
Horizontal Pan: Left arrow/ Right arrow
Vertical pan: P/L


MOUSE
Drag and drop the cannonhead near the cannon
Left Click on the left and right arrows on the power bar to increase or decrease the speed
Left Click on the centre of the ammo image to shoot
Right click on the centre of the ammo image to reset ball
Scroll up and down to zoom in and zoom out

There are three types of obstacles
stone - Unbreakable 
glass - breaks on first shot
wood - breaks on second shot

points:
glass +10
coins +50
green pig +100